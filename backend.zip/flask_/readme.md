
# Steps to run

Install the backend.zip file and extract all the folders.

type in cmd: \
cd flask_ (if not already in flask_)
pip install -r requirements.txt
python smart_gym_trainer.py  

Check the api working at localhost:5000 🙂 